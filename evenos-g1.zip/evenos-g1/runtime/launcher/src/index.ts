import { mentra } from "@evenos/mentra-bridge";
export type AppMeta = { id: string; name: string; permissions?: string[] };
export type AppModule = { mount(container: HTMLElement): void; unmount?(): void };
export class Launcher {
  private registry = new Map<string, () => Promise<AppModule>>();
  register(meta: AppMeta, loader: () => Promise<AppModule>) {
    this.registry.set(meta.id, loader);
  }
  async start(appId: string, container: HTMLElement) {
    const loader = this.registry.get(appId);
    if (!loader) throw new Error(`App ${appId} not registered`);
    const app = await loader(); app.mount(container);
  }
}
export async function bootstrap(container: HTMLElement) {
  const info = await mentra.deviceInfo();
  container.innerHTML = `<div>EvenOS-G1 • ${info.model}</div>`;
}