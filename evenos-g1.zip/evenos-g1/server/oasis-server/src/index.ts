import { AppServer, AppSession, ViewType } from "@mentra/sdk";
const PACKAGE_NAME = process.env.PACKAGE_NAME || "com.playerclosed.oasis";
const PORT = parseInt(process.env.PORT || "3000", 10);
const API_KEY = process.env.MENTRAOS_API_KEY;
if (!API_KEY) { console.error("MENTRAOS_API_KEY missing"); process.exit(1); }

class OasisServer extends AppServer {
  protected async onSession(session: AppSession) {
    await session.layouts.showDoubleTextWall("Mini-OASIS", "Kurz: weiter • Lang: auswählen", { view: ViewType.MAIN, durationMs: -1 });
    session.events.onButtonPress(async (btn) => {
      if ((btn.durationMs ?? 0) > 600) {
        await session.layouts.showReferenceCard("Portal", "Reise…", { view: ViewType.MAIN, durationMs: 1200 });
      } else {
        await session.layouts.showDashboardCard("Ziel", "weiter…", { view: ViewType.MAIN, durationMs: 900 });
      }
    });
  }
}
new OasisServer({ packageName: PACKAGE_NAME, apiKey: API_KEY, port: PORT }).start().catch(console.error);