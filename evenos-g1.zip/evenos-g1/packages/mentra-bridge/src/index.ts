export type DeviceInfo = { model: string; os: string; batteryPct?: number };
const isMentra = typeof globalThis !== 'undefined' && (globalThis as any).mentra;
export const mentra = {
  speech: {
    async recognizeOnce(opts?: { lang?: string }): Promise<string> {
      if (isMentra) return await (globalThis as any).mentra.speech.recognizeOnce(opts);
      return Promise.reject(new Error('Mic not available in mock'));
    }
  },
  async deviceInfo(): Promise<DeviceInfo> {
    if (isMentra) return await (globalThis as any).mentra.device.info();
    return { model: 'Desktop', os: navigator.userAgent };
  }
};